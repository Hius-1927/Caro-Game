namespace GameCaro.Properties
{
    using System;
    using System.Drawing;

    internal class Resources
    {
        internal static Bitmap caro
        {
            get
            {
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "caro.png");
                if (System.IO.File.Exists(path))
                {
                    try
                    {
                        return (Bitmap)Image.FromFile(path);
                    }
                    catch { }
                }
                // Fallback
                Bitmap bmp = new Bitmap(263, 263);
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.Clear(Color.LightGray);
                }
                return bmp;
            }
        }
    }
}
